#!/bin/bash

tmux kill-session -t stc 2>/dev/null